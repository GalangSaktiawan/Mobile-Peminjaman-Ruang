import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class Peminjaman {
  final String idPeminjaman;
  final String nomorInduk;
  final String namaRuang;
  final String waktuPinjam;
  final String durasi;
  final String statusPinjam;

  Peminjaman({
    required this.idPeminjaman,
    required this.nomorInduk,
    required this.namaRuang,
    required this.waktuPinjam,
    required this.durasi,
    required this.statusPinjam,
  });

  factory Peminjaman.fromJson(Map<String, dynamic> json) {
    return Peminjaman(
      idPeminjaman: json['id_peminjaman']?.toString() ?? '',
      nomorInduk: json['nomor_induk']?.toString() ?? '',
      namaRuang: json['nama_ruang']?.toString() ?? '',
      waktuPinjam: json['waktu_pinjam']?.toString() ?? '',
      durasi: json['durasi']?.toString() ?? '',
      statusPinjam: json['status_pinjam']?.toString() ?? '',
    );
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Peminjaman Ruangan',
      debugShowCheckedModeBanner: false,
      home: PeminjamanPage(),
    );
  }
}

class PeminjamanPage extends StatefulWidget {
  const PeminjamanPage({super.key});

  @override
  State<PeminjamanPage> createState() => _PeminjamanPageState();
}

class _PeminjamanPageState extends State<PeminjamanPage> {
  final String baseUrl = 'https://galang.sbs';

  List<Peminjaman> daftarPeminjaman = [];
  bool isLoading = true;

  final TextEditingController nomorIndukController = TextEditingController();
  final TextEditingController ruanganController = TextEditingController();
  final TextEditingController durasiController = TextEditingController();

  @override
  void initState() {
    super.initState();
    ambilDataPeminjaman();
  }

  @override
  void dispose() {
    nomorIndukController.dispose();
    ruanganController.dispose();
    durasiController.dispose();
    super.dispose();
  }

  Future<void> ambilDataPeminjaman() async {
    if (mounted) {
      setState(() {
        isLoading = true;
      });
    }

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api_peminjaman.php'),
      );

      if (response.statusCode == 200) {
        final hasilDecode = jsonDecode(response.body);

        List dataJson;
        if (hasilDecode is List) {
          dataJson = hasilDecode;
        } else if (hasilDecode is Map && hasilDecode['data'] != null) {
          dataJson = hasilDecode['data'];
        } else {
          dataJson = [];
        }

        if (mounted) {
          setState(() {
            daftarPeminjaman =
                dataJson.map((item) => Peminjaman.fromJson(item)).toList();
          });
        }
      } else {
        tampilPesan('Gagal mengambil data. Status: ${response.statusCode}');
      }
    } catch (e) {
      tampilPesan('Terjadi error saat mengambil data: $e');
    }

    if (mounted) {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> tambahPeminjaman() async {
    if (nomorIndukController.text.isEmpty ||
        ruanganController.text.isEmpty ||
        durasiController.text.isEmpty) {
      tampilPesan('Semua field wajib diisi');
      return;
    }

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api_insert.php'),
        body: {
          'id_peminjaman': '',
          'nomor_induk': nomorIndukController.text,
          'nama_ruang': ruanganController.text,
          'waktu_pinjam': DateTime.now().toString(),
          'durasi': durasiController.text,
          'status_pinjam': 'Pending',
        },
      );

      if (response.statusCode == 200) {
        final result = jsonDecode(response.body);

        if (result['status'] == true) {
          bersihkanForm();
          if (mounted) Navigator.pop(context);
          await ambilDataPeminjaman();
          tampilPesan(result['message'] ?? 'Data berhasil disimpan');
        } else {
          tampilPesan(result['message'] ?? 'Data gagal disimpan');
        }
      } else {
        tampilPesan('Server error: ${response.statusCode}');
      }
    } catch (e) {
      tampilPesan('Gagal menyimpan data: $e');
    }
  }

  Future<void> updatePeminjaman(String id) async {
    if (nomorIndukController.text.isEmpty ||
        ruanganController.text.isEmpty ||
        durasiController.text.isEmpty) {
      tampilPesan('Semua field wajib diisi');
      return;
    }

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api_update.php'),
        body: {
          'id_peminjaman': id,
          'nomor_induk': nomorIndukController.text,
          'nama_ruang': ruanganController.text,
          'waktu_pinjam': DateTime.now().toString(),
          'durasi': durasiController.text,
          'status_pinjam': 'Updated',
        },
      );

      if (response.statusCode == 200) {
        final result = jsonDecode(response.body);

        if (result['status'] == true) {
          bersihkanForm();
          if (mounted) Navigator.pop(context);
          await ambilDataPeminjaman();
          tampilPesan(result['message'] ?? 'Data berhasil diupdate');
        } else {
          tampilPesan(result['message'] ?? 'Data gagal diupdate');
        }
      } else {
        tampilPesan('Server error: ${response.statusCode}');
      }
    } catch (e) {
      tampilPesan('Gagal mengupdate data: $e');
    }
  }

  Future<void> hapusPeminjaman(String id) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api_delete.php'),
        body: {
          'id_peminjaman': id,
        },
      );

      if (response.statusCode == 200) {
        final result = jsonDecode(response.body);
        if (result['status'] == true) {
          await ambilDataPeminjaman();
          tampilPesan(result['message'] ?? 'Data berhasil dihapus');
        } else {
          tampilPesan(result['message'] ?? 'Data gagal dihapus');
        }
      } else {
        tampilPesan('Server error: ${response.statusCode}');
      }
    } catch (e) {
      tampilPesan('Gagal menghapus data: $e');
    }
  }

  void bersihkanForm() {
    nomorIndukController.clear();
    ruanganController.clear();
    durasiController.clear();
  }

  void tampilPesan(String pesan) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(pesan), duration: const Duration(seconds: 2)),
    );
  }

  void tampilForm({Peminjaman? peminjaman}) {
    if (peminjaman != null) {
      nomorIndukController.text = peminjaman.nomorInduk;
      ruanganController.text = peminjaman.namaRuang;
      durasiController.text = peminjaman.durasi;
    } else {
      bersihkanForm();
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) {
        return Padding(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 20,
            bottom: MediaQuery.of(context).viewInsets.bottom + 20,
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  peminjaman == null ? 'Tambah Peminjaman' : 'Edit Peminjaman',
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: nomorIndukController,
                  decoration: const InputDecoration(
                    labelText: 'Nomor Induk Peminjam',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: ruanganController,
                  decoration: const InputDecoration(
                    labelText: 'Nama Ruangan',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: durasiController,
                  decoration: const InputDecoration(
                    labelText: 'Durasi (Jam / Hari)',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () async {
                      if (peminjaman == null) {
                        await tambahPeminjaman();
                      } else {
                        await updatePeminjaman(peminjaman.idPeminjaman);
                      }
                    },
                    child: Text(peminjaman == null ? 'Simpan' : 'Update'),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void konfirmasiHapus(Peminjaman peminjaman) {
    showDialog(
      context: context,
      builder: (_) {
        return AlertDialog(
          title: const Text('Konfirmasi Hapus'),
          content: Text('Hapus peminjaman ruang ${peminjaman.namaRuang}?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () async {
                Navigator.pop(context);
                await hapusPeminjaman(peminjaman.idPeminjaman);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              child: const Text('Hapus'),
            ),
          ],
        );
      },
    );
  }

  Widget itemPeminjaman(Peminjaman pnj, int nomorUrut) {
    return Card(
      margin: const EdgeInsets.all(10),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: Colors.teal,
          foregroundColor: Colors.white,
          child: Text(nomorUrut.toString()),
        ),
        title: Text(pnj.namaRuang,
            style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(
          'Peminjam: ${pnj.nomorInduk}\nWaktu: ${pnj.waktuPinjam}\nDurasi: ${pnj.durasi} (${pnj.statusPinjam})',
        ),
        isThreeLine: true,
        trailing: PopupMenuButton<String>(
          onSelected: (value) {
            if (value == 'edit') {
              tampilForm(peminjaman: pnj);
            } else if (value == 'delete') {
              konfirmasiHapus(pnj);
            }
          },
          itemBuilder: (context) => const [
            PopupMenuItem(value: 'edit', child: Text('Edit')),
            PopupMenuItem(
                value: 'delete',
                child: Text('Delete', style: TextStyle(color: Colors.red))),
          ],
        ),
      ),
    );
  }

  Widget tampilBody() {
    if (isLoading) return const Center(child: CircularProgressIndicator());
    if (daftarPeminjaman.isEmpty) {
      return RefreshIndicator(
        onRefresh: ambilDataPeminjaman,
        child: ListView(
          children: const [
            SizedBox(height: 250),
            Center(child: Text('Data peminjaman ruangan belum tersedia')),
          ],
        ),
      );
    }
    return RefreshIndicator(
      onRefresh: ambilDataPeminjaman,
      child: ListView.builder(
        itemCount: daftarPeminjaman.length,
        itemBuilder: (context, index) =>
            itemPeminjaman(daftarPeminjaman[index], index),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Peminjaman Ruangan'),
        backgroundColor: Colors.teal,
        actions: [
          IconButton(
              onPressed: ambilDataPeminjaman, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: tampilBody(),
      floatingActionButton: FloatingActionButton(
        onPressed: () => tampilForm(),
        backgroundColor: Colors.teal,
        child: const Icon(Icons.add),
      ),
    );
  }
}
