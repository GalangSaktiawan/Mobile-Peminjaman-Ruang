package com.example.galang

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
